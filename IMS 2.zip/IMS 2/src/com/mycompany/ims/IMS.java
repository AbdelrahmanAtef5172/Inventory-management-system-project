/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ims;

/**
 *
 * @author ahmme
 */
public class IMS {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
