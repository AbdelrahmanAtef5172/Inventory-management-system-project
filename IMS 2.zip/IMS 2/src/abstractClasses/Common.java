package abstractClasses;

public abstract class Common {
    //ABSTRACT METHOD TO GET THE LINE REPRESENTATION OF OBJECT'S DATA
    public abstract String lineRepresentation();
    //ABSTRACT METHOD TO GET THE ID OF THE OBJECT
    public abstract String getSearchKey();

}
